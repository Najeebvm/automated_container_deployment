# Network-CA1
Automated Container deployment and Administration
The objective of this assessment is to evaluate your understanding and practical application of deploying Docker containers using Ansible.